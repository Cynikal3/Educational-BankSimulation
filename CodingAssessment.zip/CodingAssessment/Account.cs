﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingAssessment
{
    class Account
    {
        public enum AccountType_enum
        {
            Savings,
            Checking
        }

        public enum SavingsType_enum
        {
            Basic,
            Advanced
        }

        public AccountType_enum AccountType;
        public SavingsType_enum SavingsType; //Only used if AccountType = Savings

        public int AccountId = 0;
        public int OwnerId = 0;
        public decimal Balance = 0.00m; //Decimal used for accurate balances in the USD notation.

        public List<string> AccountLog = new List<string>(); //Any logging used for the account in question.
    }
}
